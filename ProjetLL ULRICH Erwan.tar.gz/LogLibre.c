/*Copyright 2016 Ulrich Erwan*/

//PREAMBLE 

/*The GNU General Public License is a free, copyleft license for software and other kinds of works.

The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program--to make sure it remains free software for all its users. We, the Free Software Foundation, use the GNU General Public License for most of our software; it applies also to any other work released this way by its authors. You can apply it to your programs, too.

When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things.

To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others.

For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights.

Developers that use the GNU GPL protect your rights with two steps: (1) assert copyright on the software, and (2) offer you this License giving you legal permission to copy, distribute and/or modify it.

For the developers' and authors' protection, the GPL clearly explains that there is no warranty for this free software. For both users' and authors' sake, the GPL requires that modified versions be marked as changed, so that their problems will not be attributed erroneously to authors of previous versions.

Some devices are designed to deny users access to install or run modified versions of the software inside them, although the manufacturer can do so. This is fundamentally incompatible with the aim of protecting users' freedom to change the software. The systematic pattern of such abuse occurs in the area of products for individuals to use, which is precisely where it is most unacceptable. Therefore, we have designed this version of the GPL to prohibit the practice for those products. If such problems arise substantially in other domains, we stand ready to extend this provision to those domains in future versions of the GPL, as needed to protect the freedom of users.

Finally, every program is threatened constantly by software patents. States should not allow patents to restrict development and use of software on general-purpose computers, but in those that do, we wish to avoid the special danger that patents applied to a free program could make it effectively proprietary. To prevent this, the GPL assures that patents cannot be used to render the program non-free.

The precise terms and conditions for copying, distribution and modification follow.*/


//BASIC PERMISSIONS

/*All rights granted under this License are granted for the term of copyright on the Program, and are irrevocable provided the stated conditions are met. This License explicitly affirms your unlimited permission to run the unmodified Program. The output from running a covered work is covered by this License only if the output, given its content, constitutes a covered work. This License acknowledges your rights of fair use or other equivalent, as provided by copyright law.

You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you.

Conveying under any other circumstances is permitted solely under the conditions stated below. Sublicensing is not allowed; section 10 makes it unnecessary.*/



#include<stdio.h>
#include<stdlib.h> 
#include<time.h> // Implements srand()
#include<string.h> // Implements strcpy()/strcmp()


// List of recognized notes for the 8_BITIZER
#define DO 523
#define REB 554
#define RE 587
#define RED 622
#define MI 659
#define FA 698
#define FAD 740
#define SOL 784
#define SOLD 831
#define LA 880
#define LAD 932
#define SI 988
#define DOA 1046
#define SIG 494
#define SIBG 466
#define LAG 440
#define SOLDG 415
#define SOLG 392

#define MAXIMUM_LENGHT 20


//-------Fonctions-----------  
int choixModePlay();
int choixMode();
char* InputHandler(char * MyString);
float swiftness ();
void reverse (FILE* LeDescripteur, float swiftness);
FILE* xfopen(char* LeFichier);
int detectFrequency(char* LaNote);
void NoteTimeChoice(char* sNote);
void play(char * sNote);
void playFile();
void readfile(FILE *LeDescripteur,float swiftness);
void Accueil();


int main()
{
  char* sNote = malloc(sizeof(char)*255);
  int LeChoixMode = NULL;

  Accueil();
  LeChoixMode = choixMode();
  if(LeChoixMode == 1)
    NoteTimeChoice(sNote);
  else
    {
      playFile();
    }
  free(sNote);
  return EXIT_SUCCESS;

}


//Random mode function, picks random note and random time and plays the associated sound.
void NoteTimeChoice(char* sNote)
{
  srand(time(NULL));
  int note = (rand()%17);            
  float noteTime = 0;
   while(1)
    {
      note = (rand()%17);
      do
	{
	  noteTime = (float)rand()/(float)RAND_MAX;
	}
      while(noteTime < 0.1 || noteTime > 0.4); 
	 

      switch(note)
      {
      case 0: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime,DO);
	break;

      case 1: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, REB);
	break;

      case 2: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, RE);
	break;

      case 3: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, RED);
	break;

      case 4: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, MI);
	break;

      case 5: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, FA);
	break;

      case 6: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, FAD);
	break;

      case 7: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, SOL);
	break;

      case 8: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, SOLD);
	break;

      case 9: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, LA);
	break;

      case 10: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, LAD);
	break;

      case 11: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, SI);
	break;
	
	case 12: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, DOA);
	break;

      case 13: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, SIG);
	break;

      case 14: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, SIBG);
	break;

      case 15: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, LAG);
	break;

      case 16: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, SOLDG);
	break;

      case 17: 
	sprintf(sNote,"sox -r 8000 -n output.au synth %f sine %d",noteTime, SOLG);
	break;

      default:
	  printf("erreur\n");
      }
      play(sNote);
    }
}

// Call to system command
void play(char * sNote)
{
  system(sNote);
  system("play output.au");
}

// PlayFile mode-- Main screen  //
void playFile()
{
  float vitesse = 1; 
  char *LeFichier = malloc(sizeof(char)*20);
  FILE *LeDescripteur=NULL;
  int playMode = NULL;
 
  printf("Quel fichier voulez vous jouer ?\n");
  InputHandler(LeFichier);
  LeDescripteur = xfopen(LeFichier);

  playMode = choixModePlay();
  if(playMode == 1)
    {
      vitesse = swiftness();
      readfile(LeDescripteur,vitesse);
    }
  else
    {
      vitesse = swiftness();
      reverse(LeDescripteur,vitesse);
    }
  free(LeFichier);
  fclose(LeDescripteur);
}

//safe implementation for fopen function
FILE* xfopen(char* LeFichier)
{
  FILE *tmp = fopen(LeFichier,"r");
  while(tmp == 0)
    {
      printf("Fichier introuvable, veuillez reessayer\n");
      scanf("%s", LeFichier);
      tmp = fopen(LeFichier,"r");
    }

  return tmp;
}


// readfile function reads caractere each by one, stores it in a grid, then call Play function.
void readfile(FILE *LeDescripteur, float swiftness)
{
  char LaNote[6];
  float LeTemps = 0.0;
  int LeSleep = 0;
  int LaNote2 = 0;
  char LaCommande[50];


  while(fgetc(LeDescripteur) != EOF)
    {
      fscanf(LeDescripteur,"%s %f %d\n",LaNote,&LeTemps,&LeSleep);
      LaNote2 = detectFrequency(LaNote);
      sprintf(LaCommande,"sox -r 8000 -n output.au synth %f sine %d", LeTemps*swiftness, LaNote2);
      play(LaCommande);
      //sleep(LeSleep);
    }
}

// figure out the note with the entry read from the file given by User
int detectFrequency(char* LaNote)
{

  if (strcmp(LaNote, "DO") == 0)
    return 523;
  else if (strcmp(LaNote, "SIG") == 0)
    return 494;
  else if (strcmp(LaNote, "SIBG") == 0)
    return 466;
  else if (strcmp(LaNote, "LAG") == 0)
    return 440;
  else if (strcmp(LaNote, "SOLDG") == 0)
    return 415;
  else if (strcmp(LaNote, "SOLG") == 0)
    return 392;
  else if (strcmp(LaNote, "REB") == 0)
    return 554;
  else if (strcmp(LaNote, "RE") == 0)
    return 587;
  else if (strcmp(LaNote, "RED") == 0)
    return 662;
  else if (strcmp(LaNote, "MI") == 0)
    return 659;
  else if (strcmp(LaNote, "FA") == 0)
    return 698;
  else if (strcmp(LaNote, "FAD") == 0)
    return 740;
  else if (strcmp(LaNote, "SOL") == 0)
    return 784;
  else if (strcmp(LaNote, "SOLD") == 0)
    return 831;
  else if (strcmp(LaNote, "LA") == 0)
    return 880;
  else if (strcmp(LaNote, "LAD") == 0)
    return 932;
  else if (strcmp(LaNote, "SI") == 0)
    return 988;
  else if (strcmp(LaNote, "DOA") == 0)
    return 1046;
  else
    return 0; 
}


//reverse mode function : stores command list in a double dimention grid, upside down, then call Play function.
void reverse (FILE* LeDescripteur, float swiftness)
{
  char LesCommandes[50][50];
  char UneCommande[50];
  char LaNote[6];
  int LaNote2 = 0;
  float LeTemps = 0.0;
  float LeSleep= 0.0;
  int compteur = 0;

  while(fgetc(LeDescripteur) != EOF)
    {
      fscanf(LeDescripteur,"%s %f %f\n",LaNote,&LeTemps,&LeSleep);
      LaNote2 = detectFrequency(LaNote);
      sprintf(UneCommande, "sox -r 8000 -n output.au synth %f sine %d", LeTemps*swiftness, LaNote2);
      strcpy(LesCommandes[compteur],UneCommande);
      compteur++;
    }
  while(compteur != 0)
    {
       play(LesCommandes[compteur]);
       compteur --;
    }
}

// Swiftness function : allows User to define a multiplying/dividing coeficient for the music sample he plays 
float swiftness ()
{
  float OMG_Dat_Choucroute = 1;
  char *OMG_Dat_Ommelette = malloc(sizeof(char)*MAXIMUM_LENGHT);
  

  printf("Voulez vous accelerer(tapez '++')/ralentir(tapez '--') votre morceau ? C pour ne pas modifier \n");

  OMG_Dat_Ommelette = InputHandler(OMG_Dat_Ommelette);
  
  if(strcmp(OMG_Dat_Ommelette, "++") == 0)
    {
      printf("De combien voulez vous accelerer? (en pourcent) \n");
      scanf("%f", &OMG_Dat_Choucroute);
      OMG_Dat_Choucroute = 1-(OMG_Dat_Choucroute/100);
    }
  else if (strcmp(OMG_Dat_Ommelette, "--") == 0) 
    {
      printf("De combien voulez vous ralentir ? (en pourcent) \n");
      scanf("%1f", &OMG_Dat_Choucroute);
      OMG_Dat_Choucroute = 1+(OMG_Dat_Choucroute/100);
    }
  else if (OMG_Dat_Ommelette[0] == 'c' || OMG_Dat_Ommelette[0] == 'C')
    return 1; 

  while (OMG_Dat_Choucroute > 2 || OMG_Dat_Choucroute < 0 )
    {
      printf(" La valeur entrée n'est pas valide ! recommancez \n");
      scanf("%f", &OMG_Dat_Choucroute);
    }
  free(OMG_Dat_Ommelette);
  return OMG_Dat_Choucroute;

}

//safe_check of User input 
char* InputHandler(char * MyString)
{
  int Taille_Courante = MAXIMUM_LENGHT;
  char LeCaractere = NULL;
  int i = 0;

  if(MyString != NULL)
    {
          while( getchar() != '\n')
	{
	  //clear %d characteR
	}   

      while( (LeCaractere=getchar()) != '\n')
	{
	  //LeCaractere = getchar();
	  if( i == Taille_Courante)
	    {
	      Taille_Courante++;
	      MyString = realloc(MyString,Taille_Courante);
	      MyString[i] = LeCaractere;
	    }
	  else
	     MyString[i] = LeCaractere;
	  
	  i++;
	}

    }
  else
    {
      printf("erreur lors de l'allocation memoire");
      return 0;
    }
  return MyString;
}

// User choose the Mode he wants to use
int choixMode()
{
  int LeChoix = NULL;

  printf(" Quel mode voulez vous utiliser ?\n");
  printf("----1) Ramdom Music\n----2)Play from a file\n");
  scanf("%d", &LeChoix);
  while(LeChoix < 1 || LeChoix > 2)
     {
       printf("Ne faites pas l'idiot, choisissez entre 1 et 2\n");
       scanf("%d", &LeChoix);
     }

  return LeChoix;
}


//user chooses mode for the sample he wants to play ( normal or reverse)
int choixModePlay()
{
  int LeModePlay = NULL;
  int i = 1;

  printf("------Plusieurs Options s'offrent à vous--------\n");
  printf("---1)  mode Normal\n");
  printf("---2)  mode Reverse\n");

  do
    {
      scanf("%d", &LeModePlay);
      if(i > 1)
	printf("Ne faites pas l'idiot, choisissez entre 1 et 2\n");

      i++;
    }

  while(LeModePlay < 1 && LeModePlay > 3);
	
  return LeModePlay;
}

// displays a sober command-line interface
void Accueil()
{
  printf("-----------Bienvenu dans le 8-BITIZER-------------\n");
  printf("           ~~~~~~~~~~~~~~~~~~~~~~~~~~             \n\n");
  printf(" Le 8-BITIZER est un programme en ligne de commande qui permet de jouer \n de la musique a partir d'un fichier .gek\n\n");
}
